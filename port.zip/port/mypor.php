<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css
    " integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="mypor.css">
    <script src="mypor1.js">
    </script>
</head>

<body>
    <header class="header">
        <a href="#" class="logo">Ajme</a>
        <i class="fa-solid fa-bars" class="menu-icon" id="menu-icon"></i>
        <nav class="navbar">
            <a href="#HOME" class="active">Home</a>
            <a href="#service">SERVICE</a>
            <a href="#skill">SKILL</a>
            <a href="#education">EDUCATION</a>
            <a href="#contact">CONTACT</a>
            <a href="index.php">Login</a>


    </header>
    <section class="home" id="home">
        <div class="home-img">
            <img src="img6.jpg" alt="" style="margin-top: 50px;">
        </div>
        <div class="home-content">
            <h1>HI, It's<span>Ajme</span></h1>
            <h3 class="typing-text">I'am a <span></span></h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Amet dolorem voluptate inventore, illo porro placeat
                consequatur nisi non officiis. Culpa, sed libero! Voluptate
                ut natus reprehenderit laudantium dolorum, hic tenetur!</p>
            <div class="social-icon">
                <a href="https://www.linkedin.com/public-profile/settings?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_self_edit_contact-info%3BEz5YeZb7Snyn%2FGvRvfak5Q%3D%3D"><i class="fa-brands fa-linkedin"></i></a>
                <a href="https://github.com/ajme-abes"><i class="fa-brands fa-github"></i></a>
                <a href="#"><i class="fa-brands fa-square-twitter"></i></a>
                <a href="https://www.instagram.com/ajmelabes/"><i class="fa-brands fa-instagram"></i></a>
                <a href="https://t.me/Ajmelock"><i class="fa-brands fa-telegram"></i></a>
            </div>
            <a href="#" class="btn">Hire Me</a>

        </div>
    </section>
    <section class="Service" id="service">
        <h2 class="heading" style="margin-left: 30%; font-weight: 600; font-size: 100px; margin-top: 40px;">Service</h2>
        <div class="service-container">
            <div class="service-box">
                <div class="service-info">
                    <h4>Software Designer</h4>
                    <p>in the future I will Devlop diffrent Software</p>
                </div>
            </div>
            <div class="service-box">
                <div class="service-info">
                    <h4>FrontEnd Devloper</h4>
                    <p>i can design or develop front end with many language </p>
                </div>
            </div>
            <div class="service-box">
                <div class="service-info">
                    <h4>Script kidd</h4>
                    <p>I do the script to some extent</p>
                </div>
            </div>
            <div class="service-box">
                <div class="service-info">
                    <h4>Future AiDevloper</h4>
                    <p>in the future I will do ai</p>
                </div>
            </div>
        </div>
    </section>
    <section class="skill" id="skill">
        <h2 class="heading" style="margin-left: 30%; font-weight: 600; font-size: 100px; margin-top: 40px;">Skill</h2>
        <div class="container">
            <div class="row" id="skill-container">
                <div class="bar">
                    <div class="info">
                        <img src="fig1.png" alt="" style="height: 20px;">
                        <span>Figma</span>
                    </div>

                </div>
                <div class="bar">
                    <div class="info">
                        <img src="j.png" alt="" style="height: 20px;">
                        <span>Java</span>
                    </div>

                </div>
                <div class="bar">
                    <div class="info">
                        <img src="ht.png" alt="" style="height: 20px;">
                        <span>Html</span>
                    </div>

                </div>
                <div class="bar">
                    <div class="info">
                        <img src="c.png" alt="" style="height: 20px;">
                        <span>C++</span>
                    </div>
                </div>
                <div class="bar">
                    <div class="info">
                        <img src="py.png" alt="" style="height: 20px; width: 20px;">
                        <span>Python</span>
                    </div>

                </div>
                <div class="bar">
                    <div class="info">
                        <img src="img8.png" alt="" style="height: 20px; width: 20px;">
                        <span>JavaScript</span>
                    </div>

                </div>

            </div>
        </div>
    </section>
    <section class="education" id="education">
        <h2 class="heading" style="margin-left: 30%; font-weight: 600; font-size: 100px;">My <span>Education</span></h2>
        <div class="timeline">
            <div class="container right">
                <div class="content">
                    <div class="tag">
                        <h2>University</h2>

                    </div>
                    <div class="decs">
                        <p>i am a 3 year computer science student of mwu.</p>
                    </div>
                </div>
            </div>
            <div class="container left">
                <div class="content">
                    <div class="tag">
                        <h2>Hig School</h2>

                    </div>
                    <div class="decs">
                        <p>i am studied from grade 9-8 in mechara secondary school</p>
                    </div>
                </div>
            </div>
            <div class="container right">
                <div class="content">
                    <div class="tag">
                        <h2>Elementry</h2>

                    </div>
                    <div class="decs">
                        <p>i am studied from grade 5-8 in mechara primary school.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="contact" id="contact">
        <h2 class="heading" style="margin-left: 30%; font-weight: 600; font-size: 100px;">Contact <span>Me</span></h2>
        <form action="">
            <div class="input-box">
                <input type="text" name="name" placeholder="name" required>
                <input type="email" placeholder="email" required>
                <input type="number" placeholder="phone number" required>
                <input type="text" placeholder="subject">
            </div>
            <textarea name="" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
            <input type="submit" value="Send message" class="btn"><a href="message.php"></a>
        </form>
    </section>
    <footer class="footer">
        <div class="social">
            <a href="#"><i class="fa-brands fa-github"></i></a>
            <a href="#"><i class="fa-brands fa-linkedin"></i></a>
            <a href="#"><i class="fa-brands fa-instagram"></i></a>
            <a href="#"><i class="fa-brands fa-facebook"></i></a>
            <a href="#"><i class="fa-brands fa-telegram"></i></a>
            <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
        </div>
        <ul class="list">
            <li><a href="#">FAQ</a></li>
            <li><a href="Service.htmlsw">Service</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">Privacy policies</a></li>
        </ul>
        <p class="copyright">
            <i class="fa-regular fa-copyright"></i> Ajme abes| All Right Reserved
        </p>
    </footer>
</body>

</html>