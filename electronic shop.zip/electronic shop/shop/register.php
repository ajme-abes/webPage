<?php

include 'connect.php';

session_start();

if (isset($_SESSION['user_id'])) {
  $user_id = $_SESSION['user_id'];
} else {
  $user_id = '';
};

if (isset($_POST['submit'])) {

  $name = $_POST['name'];
  $name = filter_var($name, FILTER_SANITIZE_STRING);
  //$username = $_POST['username'];
  //$username = filter_var($username, FILTER_SANITIZE_STRING);
  $email = $_POST['email'];
  $email = filter_var($email, FILTER_SANITIZE_STRING);
  $pass = sha1($_POST['pass']);
  $pass = filter_var($pass, FILTER_SANITIZE_STRING);
  $cpass = sha1($_POST['cpass']);
  $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

  $select_user = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
  $select_user->execute([$email,]);
  $row = $select_user->fetch(PDO::FETCH_ASSOC);

  if ($select_user->rowCount() > 0) {
    $message[] = 'email already exists!';
  } else {
    if ($pass != $cpass) {
      $message[] = 'confirm password not matched!';
    } else {
      $insert_user = $conn->prepare("INSERT INTO `users`(name, username, email, password) VALUES(?,?,?,?)");
      $insert_user->execute([$name, $username, $email, $cpass]);
      $message[] = 'registered successfully, login now please!';
    }
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Electronic Shop</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
  <!-- bootstrap links -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- bootstrap links -->
  <!-- fonts links -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Merriweather&display=swap" rel="stylesheet">
  <!-- fonts links -->
</head>

<body>
  <?php include 'header.php'; ?>
  <form action="" method="post">
    <div class="container" id="login">
      <div class="row">
        <div class="col-md-5 py-3 py-md-0" id="side1">
          <h3 class="text-center">Register</h3>
        </div>
        <div class="col-md-7 py-3 py-md-0" id="side2">
          <form action="" method="post" autocomplete="off">
            <h3 class="text-center">Create Account</h3>
            <div class="input2 text-center">
              <input type="name" name="name" placeholder="Name" required>
              <!-- <input type="name" placeholder="UserName" name="username" required>-->
              <!--<input type="name" placeholder="User Name">-->
              <!--<input type="number" placeholder="Phone">-->
              <input type="email" name="email" placeholder="Email" required>
              <input type="password" name="pass" placeholder="Password" required>
              <input type="confirm password" name="cpass" placeholder="confirm Password" required>
              <p class="text-center" id="btnlogin"><input type="submit" name="submit" style=" border-radius: 10px; border:2px solid #ffc800; width:100px;"></p>

            </div>
          </form>
        </div>

      </div>
    </div>
  </form>


  <!-- newslater -->
  <div class="container" id="newslater" style="margin-top: 100px;">
    <h3 class="text-center">Subscribe To The Electronic Shop For Latest upload.</h3>
    <div class="input text-center">
      <input type="text" placeholder="Enter Your Email..">
      <button id="subscribe">SUBSCRIBE</button>
    </div>
  </div>
  <!-- newslater -->






  <!-- footer -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Electronic Shop</h3>
            <p>
              ROBE <br>
              OROMIA <br>
              ETHIOPHIA <br>
            </p>
            <strong>Phone:</strong> +000000000000000 <br>
            <strong>Email:</strong> electronicshop@.com <br>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Usefull Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Terms of service</a></li>
              <li><a href="#">Privacy policey</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>

            <ul>
              <li><a href="#">PS 5</a></li>
              <li><a href="#">Computer</a></li>
              <li><a href="#">Gaming Laptop</a></li>
              <li><a href="#">Mobile Phone</a></li>
              <li><a href="#">Gaming Gadget</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, quibusdam.</p>

            <div class="socail-links mt-3">
              <a href="#"><i class="fa-brands fa-twitter"></i></a>
              <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
              <a href="#"><i class="fa-brands fa-instagram"></i></a>
              <a href="#"><i class="fa-brands fa-skype"></i></a>
              <a href="#"><i class="fa-brands fa-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </div>
    <hr>
    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>Electronic Shop</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="#">SA coding</a>
      </div>
    </div>
  </footer>
  <!-- footer -->







  <a href="#" class="arrow"><i><img src="./images/arrow.png" alt=""></i></a>













  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>